package com.TriviaBlitzProject.triviablitzmain;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TextView;

import java.util.HashSet;

public class MainActivity extends AppCompatActivity {

    private int questionCount = 0;
    String[] questionLabels;
    HashSet<Questions> questionSet = new HashSet<Questions>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Resources resource = getResources();
        questionLabels = resource.getStringArray(R.array.question_count);
        TextView currentQuestionLabel = findViewById(R.id.question_number_text_view);
        currentQuestionLabel.setText(questionLabels[questionCount]);

        for(Questions currQuestion : questionSet)
        {
            currentQuestionLabel.setText(questionLabels[questionCount++]);
        }
        //TODO read questions from file/database
        //TODO create logic to loop while populating the HashSet randomly with question objects from the read in file.


    }
}